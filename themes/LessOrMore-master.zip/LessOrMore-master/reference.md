---
layout: post
title: 相关博客
permalink: /reference/
---

* content
{:toc}


走向架构师之路
=====================
[走向架构师之路](http://blog.csdn.net/cutesource/article/details/4901506)

HTTP协议详解
=====================
[HTTP协议详解](http://www.jmarshall.com/easy/http/)

Axis 2.0的入门
=====================
[曹胜欢][http://blog.csdn.net/csh624366188/article/details/8362696](http://blog.csdn.net/csh624366188/article/details/8362696)

高爽|Coder 
=====================
这个人的博客对java底层的东西研究比较深入。
[http://blog.csdn.net/ghsau/article/details/20395681](http://blog.csdn.net/ghsau/article/details/20395681)

[一线码农]
=====================
算法入门和分布式缓存入门
[http://www.cnblogs.com/huangxincheng/archive/2011/11/14/2249046.html](http://www.cnblogs.com/huangxincheng/archive/2011/11/14/2249046.html)

[通向架构师的道路]
=====================
说实话没仔细看过这些博客，纯粹被标题吸引
[http://blog.csdn.net/lifetragedy](http://blog.csdn.net/lifetragedy)
http://blog.csdn.net/lifetragedy

[冯立彬的博客]
=====================
话说这哥们是个大牛，以前看过一些文章。
[http://blog.csdn.net/fenglibing](http://blog.csdn.net/fenglibing)

[汪海的实验室]
=====================
一个14年毕业的学生，差距啊！
[http://blog.csdn.net/pleasecallmewhy/article/details/8923725](http://blog.csdn.net/pleasecallmewhy/article/details/8923725)

[Byvoid]
=====================
Linux中文输入法，node.js开发指南的原作者。14年大学本科清华毕业
[https://www.byvoid.com/](https://www.byvoid.com/)

[rowen的专栏]
=====================
数据挖掘的基础入门
[http://blog.csdn.net/luowen3405/article/details/6331763](http://blog.csdn.net/luowen3405/article/details/6331763)

[淘宝团队的博客]
=====================
淘宝团队的积累
[http://www.searchtb.com/](http://www.searchtb.com/)

[axman]
=====================
多线程相关写的比较好
[http://blog.csdn.net/axman/article/category/894625](http://blog.csdn.net/axman/article/category/894625)

[旺仔专栏]
=====================
Windows下FFmpeg快速入门
[http://blog.csdn.net/hemingwang0902/article/details/4382429](http://blog.csdn.net/hemingwang0902/article/details/4382429)